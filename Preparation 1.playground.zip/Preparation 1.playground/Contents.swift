//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .white

        let label = UILabel()
        label.frame = CGRect(x: 150, y: 200, width: 200, height: 20)
        label.text = "Hello World!"
        label.textColor = .black
        
        view.addSubview(label)
        self.view = view
    }
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()

//--------------------------------------------------------------------
//                            class Example
//--------------------------------------------------------------------

class Phone {
    var model1 :String
    init(model1:String) {
        self.model1 = model1
    }
}
var model2 = Phone(model1:"Iphone")
var model3 = model2
model2.model1 = "Lenovo"
model2.model1
model3.model1

model2.model1 = "Lava"
model3.model1
model2.model1

//

class Practice {
    var name : String
    var id:Int
    init(name:String,id:Int) {
        self.name = name
        self.id = id
        
    }
}
var ca = Practice(name:"Satyam",id:0)
print(ca.name)
var cb = ca
print(ca.name)
print(cb.name)
cb.name = "Medidi"
cb.id = 1
print(ca.name)
print(cb.name)
print(ca.id)
print(cb.id)
//--------------------------------------------------------------------
// Basic Class Ex
//--------------------------------------------------------------------

class Student{
    var s1 = 99
    var s2 = 89
    var s3 = 87
}
let result = Student()
print("Subject1 Marks is \(result.s1)")
print("Subject2 Marks is \(result.s2)")
print("Subject3 Marks is \(result.s3)")
print("Total Marks \(result.s1 + result.s2 + result.s3)")

//--------------------------------------------------------------------
//                            Structures Examples
//--------------------------------------------------------------------



struct Practice1 {
    var name :String
    init(name:String) {
        self.name = name
    }
}
var sa = Practice1(name:"Medidi")
print(sa.name)
var sb = sa
print(sb.name)
sb.name = "Satyam"
print(sa.name)
print(sb.name)


//2
struct Demo {
    var name:String
    init(name:String) {
        self.name = name
    }
}
 var sPhone1 = Demo(name:"Lenovo")
var sPhone2 = sPhone1
sPhone2.name = "Apple"
sPhone1.name
sPhone2.name

sPhone1.name = "6S"
sPhone1.name
sPhone2.name




//--------------------------------------------------------------------
// Struct than Class
//--------------------------------------------------------------------

class Vehicle  {
    var name : String
    init(name:String) {
        self.name = name
    }
    
}
class Car:Vehicle {
    
}
//
//--------------------------------------------------------------------
// Clousures
//--------------------------------------------------------------------

let names = ["Satya","Venkat","Medidi","D"]
func reverseNames(_ s1: String, _ s2: String) -> Bool {
    return s1 > s2
}
var results = names.sorted(by: reverseNames)



//Smaller number using Clousers

let array = [0,1,2,3,5,6,7,8]
let smallerThanTwo = array.filter { $0 < 8 }
print(smallerThanTwo)
let smallerNumberCount = array.count
print("Smaller number Count is \(smallerNumberCount)")
let smallerNumbers = array.filter{$0 > 7 }
print("Smaller Numbers are \(smallerNumbers)")


//--------------------------------------------------------------------
// Tuple
//--------------------------------------------------------------------


//Number Sort
var numbers = [1, 4, 2, 5, 8, 3]

numbers.sort(by: <) // this will sort the array in ascending order
numbers.sort(by: >) // this will sort the array in descending order

//Named tuples -- 1
var person1 = (first:"Medidi",last:"Satyam")
var first = person1.first
var last = person1.last

//
var point = (0,0)
point.0 = 1
point.1 = 2

//
var person2 = ("Medidi","Satyam")
var pFirstName = person2.0
var pLastName = person2.1

//Tuple Copy
var origin = (x: 1000, y: 10)

var point1 = origin
point1.x = 300
point1.y = 5658

print(origin)
print(point1)  //Tuples Are value types thats way not changed the Previoues values.

//Tuple type

var number = 1212
number
print(number)

//Decomposing Tuples
var person = (firstName: "John", lastName: "Smith")
print(person.firstName)
print(person.lastName)

var (firstName, lastName) = person

var (onlyFirstName, _) = person
var (_, onlyLastName) = person

print(firstName)
print(lastName)

//Multiple Tuples
var a1 = 1
var b1 = 2
var c1 = 3

var (a,b,c) = (1,2,3) //other form

//Retureing values from functions Tuple As a results type

func division (a:Int,b:Int) -> (Int,Int)
{
    return (a/b,a % b)
}
division( a:4, b:2)

var person4 = (a:1 , bn:2)
person4.0 = 233
person4.1 = 34


//Compare Two tuples

let persons4 = (name:"Satyam",last: "Swift")
let persons5 = (name:"Medidi", last:"Javaw")

if persons4  == persons5 {
    
    print("Matching tuples!")
} else {
    print("Non-matching tuples!")
}


//
let singer = ("Taylor", "Swift")
let alien = ("Justin", "Bieber")

if singer == alien {
    print("Matching tuples!")
} else {
    print("Non-matching tuples!")
}

//
let singer1 = (first: "Taylor", last: "Swift")
let bird = (name: "Taylor", type: "Swift")

if singer1 == bird {
    print("Matching tuples!")
} else {
    print("Non-matching tuples!")
}


//--------------------------------------------------------------------
//Enums
//--------------------------------------------------------------------
enum appleproducts {
    case iphone
    case watch
    case mac
}
var product1 = appleproducts.iphone
var product2 = appleproducts.watch
var product3 = appleproducts.mac


//Assciated Values

enum ExampleAssociation {
    case Name(String)
    case Nums(Int, Int, Int)
}
var myName = ExampleAssociation.Name("Satyam")
var someNums = ExampleAssociation.Nums(4, 12, 16)

//Raw Values

 


enum Direction: Int {
    case Up = 1
    case Down // raw value 2
    case Left // raw value 3
    case Right // raw value 4
}

//let first = 10
//let second = 15
//let third = 18
//
//let smallest = min(min(first, second), third)




//Reversed Words

//let inputString = "Tell Cersei I want her to know it was me "
//reverseEachWord(inputString: inputString)
//
//func reverseEachWord(inputString: String)->String{
//    // Using reversed()
//    let wordsArr = String(inputString.reversed()).components(separatedBy: " ").map{ $0 }
//    var resultStr = ""
//    for var word in wordsArr{
//        if wordsArr.first != word{
//            word = word + " "
//        }
//        resultStr = word + resultStr
//    }
//    return resultStr
//}
//
//--------------------------------------------------------------------
//Extensions
//--------------------------------------------------------------------



let circlePath = UIBezierPath(arcCenter: CGPoint(x: 100,y: 100), radius: CGFloat(20), startAngle: CGFloat(0), endAngle:CGFloat(M_PI * 2), clockwise: true)

let shapeLayer = CAShapeLayer()
shapeLayer.path = circlePath.cgPath

//change the fill color
shapeLayer.fillColor = UIColor.clear.cgColor
//you can change the stroke color
shapeLayer.strokeColor = UIColor.red.cgColor
//you can change the line width
shapeLayer.lineWidth = 3.0
//layer.addSublayer(shapeLayer)










