//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"


NSMutableDictionary * dict1 = [NSMutableDictionary
    dictionaryWithObjects:@[@"Ravi",@"33",@"India",@"India"]
    forKeys:@[@"name",@"age",@"location",@"country"]];
NSMutableDictionary * dict2 = [NSMutableDictionary
    dictionaryWithObjects:@[@"33",@"India",@"India",@"Ravi"]
    forKeys:@[@"age",@"location",@"country",@"name"]];

NSMutableDictionary * dict3 = [NSMutableDictionary
    dictionaryWithObjects:@[@"Hayagreeva",@"2",@"India",@"India"]
    forKeys:@[@"name",@"age",@"location",@"country"]];
if([dict1 isEqualToDictionary:dict2])
{
    NSLog(@" dict 1 and dict 2 are equal");
}
if(![dict1 isEqualToDictionary:dict3])
{
    NSLog(@" dict 1 and dict 3 are not equal");
}