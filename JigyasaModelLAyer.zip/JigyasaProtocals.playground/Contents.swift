//: Playground - noun: a place where people can play

import UIKit

var str = "Welcome to Jigyasa"

typealias JSONDictionary = [String: Any]

//MARK:-Employee Information

struct JSEmployeeInfo {
    
    let name:String
    let email:String
    let id:Int
    let managerId:Int
    let roleId:Int
    
  /*  init(name:String,email:String,id:Int,managerId:Int,roleId:Int) {
        
        self.name = name
        self.email = email
        self.id = id
        self.managerId = managerId
        self.roleId = roleId
    }*/
    init?(withData: Any) {
        
        guard let responseDict = withData as? JSONDictionary,
            let name = responseDict[Key.name] as? String,
            let email = responseDict[Key.email] as? String,
            let roleId = responseDict[Key.role] as? Int,
            let id = responseDict[Key.id] as? Int,
            let managerId = responseDict[Key.managerId] as? Int else {
                fatalError("")
                return nil
        }
        self.id = id
        self.name = name
        self.email = email
        self.roleId = roleId
        self.managerId = managerId
        
    }
    //MARK:-Model keys
    private struct Key {
        
        static let name = "employeeName"
        static let role = "employeeRoleId"
        static let id = "employeeId"
        static let managerId = "managerId"
        static let email = "employeeEmailId"
        
    }
    
}
/*
struct JSSuggestedTrainingDataModel {
    
    let votes:String
    
    
    init(data: JSSuggestedTraining) {
        self.votes = String(data.votes)
    }
}

*/

//MARK:- Suggested Training

struct JSSuggestedTraining {
    
    let name:String
    let id:Int
    let title:String
    let trainingId:Int
    let description:String
    let votes:Int
    let hasVoted:Int
    
    init?(withData: Any) {
        
        guard let responseDict = withData as? JSONDictionary,
            let name = responseDict[Key.suggestedByEmpName] as? String,
            let title = responseDict[Key.title] as? String,
            let description = responseDict[Key.description] as? String,
            let defaultVotes = responseDict[Key.votes] as? Int,
            let employeeId = responseDict[Key.suggestedBy] as? Int,
            let trainingId  = responseDict[Key.trainingId]  as? Int,
            let hasVoted = responseDict[Key.hasVoted] as? Int else {
                fatalError("JSSuggestedTraining Initializations Failed")
                return nil
        }
        
        self.title = title
        self.id = employeeId
        self.description = description
        self.name = name
        self.trainingId = trainingId
        self.votes = defaultVotes
        self.hasVoted = hasVoted
    }
    //MARK:-Model keys
    private struct Key {
        
        static let title = "title"
        static let suggestedBy = "suggestedBy"
        static let description = "description"
        static let suggestedByEmpName = "suggestedByEmpName"
        static let trainingId = "courseId"
        static let votes = "votes"
        static let hasVoted = "hasVoted"
        
    }

    func voteForTraining(){
        // Service to vote for training
    }
    
    func getVoteCount(){
        // Service to get vote count for training
    }
    
}

//MARK:-Upcoming Traings

struct JSUpcomingTraining {
    
    let courseId : Int
    
    init?(withData: Any) {
        guard let responseDict = withData as? JSONDictionary,
            let courseId = responseDict["courseId"]  as? Int else {
                fatalError("JSUpcomingTraining Initializations Failed")
                return nil
        }
        self.courseId = courseId
    }
}

struct JSLocation {
    
    var employeeId:Int
    var place:String
    
    
    init?(withData: Any) {
        
        guard let responseDict = withData as? JSONDictionary,
        let employeeId = responseDict[Key.employeeId] as? Int,
        let location = responseDict[Key.locationName] as? String else {
                fatalError("JSLocation Initializations Failed")
                return nil
        }
        self.employeeId = employeeId
        self.place = location
    }
    //MARK:-Model keys
    private struct Key {
        
        static let employeeId = "id"
        static let locationName = "location"
       
    }
}

//MARK:- Training Schedule
struct JSSchedule {
    
    let location: String
    let startDate: String
    let endDate: String
    
  /*  init?(withData: Any) {
        guard let responseDict = withData as? JSONDictionary,
            let location = responseDict[Key.locationName] as? String,
            let startDate = responseDict[Key.startDate] as? String,
            let endDate = responseDict[Key.endDate] as? String  else {
            return nil
        }
        
        self.location = location
        self.startDate = startDate
        self.endDate = endDate
    }
    //MARK:-Model keys
    private struct Key {
        
        static let startDate = "startDateTime"
        static let endDate = "endDateTime"
        static let locationName = "location"
        
    }
 */
    
    init(location: String,startDate: String, endDate: String){
        self.location = location
        self.startDate = startDate
        self.endDate = endDate
    }
}

///
struct JSTraining {
    let schedule:JSSchedule
    let title:String
    let seats:Int
    let image:String
    let trainingId:Int
    
    struct TrainingDescription {
        
        let description:String
        var nominationCount = 0
        var requestCount = 0
        var materialLink:String
        var trainerName:String
        init?(withData: Any) {
            
            guard let responseDict = withData as? JSONDictionary,
                let description = responseDict[Key.description] as? String,
                let materialLink = responseDict[Key.materialLink] as? String,
                let trainerName = responseDict[Key.trainerName] as? String else {
                    fatalError("TrainingDescription Initializations Failed")
                    return nil
            }
            
            self.description = description
            self.materialLink = materialLink
            self.trainerName = trainerName
            
            if let nominates = responseDict["nominees"] as? Int ,let requests = responseDict["requests"] as? Int {
                self.nominationCount = nominates
                self.requestCount = requests
            }
        }
        //MARK:-Model keys
        private struct Key {
            
            static let description = "description"
            static let materialLink = "link"
            static let trainerName = "trainer"
        }
    }
    
    var trainingDescription:TrainingDescription?
    
    init?(withData: Any) {
        
        guard let responseDict = withData as? JSONDictionary,
            let location = responseDict[Key.locationName] as? String,
            let startDate = responseDict[Key.startDate] as? String,
            let endDate = responseDict[Key.endDate] as? String,
            let title = responseDict[Key.title] as? String,
            let seats = responseDict[Key.seats] as? Int,
            let trainingId  = responseDict[Key.trainingId]  as? Int,
            let image = responseDict[Key.image] as? String else {
                fatalError("JSTrainings Initializations Failed")
                return nil
        }
        
        self.title = title
        self.seats = seats
        self.trainingId = trainingId
        self.image = image
        self.schedule = JSSchedule(location: location,startDate: startDate, endDate: endDate)
}
    
    //MARK:-Model keys
    private struct Key {
        static let startDate = "startDateTime"
        static let endDate = "endDateTime"
        static let locationName = "location"
        static let title = "title"
        static let image = "image"
        static let seats = "seats"
        static let trainingId = "trainingId"
        static let description = "description"
    }
}



enum Result<T>{
    case data(T)
    case error(String)
}

protocol JSService{}

//MARK:-Protocols
extension JSService {
    
    /// User login info
    ///
    /// - Parameters:
    ///   - name: Employee email
    ///   - password: Employee password
    /// - Returns: employee full info,
    func login(name:String,password:String, onCompletion:(Result<JSEmployeeInfo>)->Void){
    
    }
}

extension JSService {
    /// Voteing for suggested training
    ///
    /// - Parameters:
    ///   - employeeId:  Suggested Employee Id
    ///   - trainingId:  Suggested Training Id
    /// - Returns: `True`
    func voteForTraining(employeeId:Int,trainingId:Int, onCompletion:(Result<Bool>)->Void){
    }
}

extension JSService {
 
    /// Vote count for suggested training
    ///
    /// - Parameters:
    ///   - employeeId:  Suggested Employee Id
    ///   - trainingId:  Suggested Training Id
    /// - Returns:`True`
    func getVoteCount(employeeId:Int,trainingId:Int, onCompletion:(Result<Bool>)->Void){
        
    }
}

extension JSService {
    /// Suggested a new training
    ///
    /// - Parameters:
    ///   - title: Training name
    ///   - description: Training description
    ///   - employeeId:  Suggested Employee Id
    /// - Returns: data or Error
    func suggestTraining(title:String,description:String,employeeId:Int, onCompletion:(Result<Bool>)->Void) {
        
        
    }

}
extension JSService {
    /// Upcoming Trainings
    ///
    /// - Parameter courseId: Training Id
    /// - Returns: data or Error
    func upcomingTrainings(courseId : Int, onCompletion:(Result<JSUpcomingTraining>)->Void) {
        
    }
    
}

extension JSService {
    /// MyTraining List
    ///
    /// - Parameters:
    ///   - desgnation: Employee Desgnation
    ///   - id: Employee id
    /// - Returns: data or Error
    func myTrainings(desgnation:Int,id:Int, onCompletion:(Result<JSTraining>)->Void) {
        
    }
    
}
extension JSService {
    /// Training Suggestions List
    ///
    /// - Parameters:
    ///   - desgnation: Employee Desgnation
    ///   - id: Employee id
    /// - Returns: data or Error
    func trainingSuggestions(desgnation:Int,id:Int, onCompletion:(Result<JSSuggestedTraining>)->Void) {
    }
    
}



