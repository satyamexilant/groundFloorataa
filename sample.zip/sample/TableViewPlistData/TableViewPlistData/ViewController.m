//
//  ViewController.m
//  TableViewPlistData
//
//  Created by medidi vv satyanarayana murty on 29/08/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    //MARK : - retrieving bundle instances.
    NSString *path = [[NSBundle mainBundle] pathForResource:@"EmployeeInformation" ofType:@"plist"];
    NSMutableDictionary *dictOfEmployee = [NSMutableDictionary dictionaryWithContentsOfFile:path];
    
    if (dictOfEmployee[@"Employee"] != nil) {
        
        self.dataArray = dictOfEmployee[@"Employee"];
    }
}


- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];
    
}

- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView {
    
    return  self.dataArray.count;
}

- (NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row {
    
    if ([tableColumn.identifier  isEqual: @"FirstName"]) {
        
        NSTableCellView *view = [tableView makeViewWithIdentifier:@"EmployeeFirstNameCell" owner:self];
        view.textField.stringValue = self.dataArray[row][@"Employee First Name"];
        return view;
        
    }else if ([tableColumn.identifier  isEqual: @"LastName"]){
        NSTableCellView *view = [tableView makeViewWithIdentifier:@"EmployeeLastNameCell" owner:self];
        view.textField.stringValue = view.textField.stringValue = self.dataArray[row][@"Employee Last Name"];;
        return view;
        
    }else if ([tableColumn.identifier  isEqual: @"Id"]){
        NSTableCellView *view = [tableView makeViewWithIdentifier:@"EmployeeIdCell" owner:self];
        view.textField.stringValue = view.textField.stringValue = self.dataArray[row][@"Employee ID"];;
        return view;
        
    }else{
        NSTableCellView *view = [tableView makeViewWithIdentifier:@"EmployeeEmailCell" owner:self];
        view.textField.stringValue = view.textField.stringValue = self.dataArray[row][@"Employee Email"];;
        return view;
    }
    
    
}




@end
