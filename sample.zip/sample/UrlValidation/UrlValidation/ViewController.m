//
//  ViewController.m
//  UrlValidation
//
//  Created by medidi vv satyanarayana murty on 31/08/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view.
}

- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}


- (IBAction)checkButton:(NSButton *)sender {

    NSString *text = self.urlTextField.stringValue;
   
//    NSURL *myURL = [NSURL URLWithString:text];
//    if (myURL && myURL.scheme && myURL.host) {
//        NSLog(@"URL is validated");
//    } else {
//        NSLog(@"URL is Not validated");
//    }
    
    [self urlIsValiad:text];
    
}


- (BOOL) urlIsValiad: (NSString *) textField
{
    NSString *urlFormat =
    @"((?:http|https)://)?(?:www\\.)?((?!-)[a-zA-Z0-9-]{2,63}(?<!-))\\.?((?:[a-zA-Z0-9]{2,})?(?:\\.[a-zA-Z0-9]{2,})?)";
    // @"((?:http|https)://)?(?:www\\.)?[\\w\\d\\-_]+\\.\\w{2,3}(\\.\\w{2})?(/(?<=/)(?:[\\w\\d\\-./_]+)?)?";
    NSPredicate *urlCheck = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", urlFormat];


    
    
    if ([urlCheck evaluateWithObject: textField] == YES) {
        NSLog(@"Entered URL is valid 👍");
    } else {
        NSLog(@"Entered URL is not valid 👎");
    }
    
    return [urlCheck evaluateWithObject:textField];
}




@end
