//
//  AppDelegate.h
//  UrlValidation
//
//  Created by medidi vv satyanarayana murty on 31/08/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

