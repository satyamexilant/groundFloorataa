//
//  ViewController.h
//  WebViewDemoApp
//
//  Created by medidi vv satyanarayana murty on 29/08/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <WebKit/WebKit.h>

@interface ViewController : NSViewController

//MARK:- WebView Out let

@property (weak) IBOutlet WKWebView *myWebView;


@end

