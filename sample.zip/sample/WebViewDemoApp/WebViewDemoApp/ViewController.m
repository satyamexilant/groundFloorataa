//
//  ViewController.m
//  WebViewDemoApp
//
//  Created by medidi vv satyanarayana murty on 29/08/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

#import "ViewController.h"


@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//MARK:- case 1
    
//    NSURL * url = [NSURL URLWithString:@"https://apple.com"];
//    NSURLRequest * request = [NSURLRequest requestWithURL:url];
//    [self.myWebView loadRequest:request];
    
    
   
//MARK:- case 2
    
    NSString *urlText = @"https://mail.exilant.com";
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:urlText]];
    [_myWebView loadRequest:request];
}


- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}


@end
