//
//  ViewController.swift
//  Demo1
//
//  Created by medidi vv satyanarayana murty on 08/08/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {
    
    @IBOutlet var first: UITextField!
    @IBOutlet var second: UITextField!
    @IBOutlet var submit: UIButton!
    
    let maxValue = 44
    let minvalue = 40
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //buttonEnable()
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func submitBtn(_ sender: Any) {
        
        let firstValue = Int(first.text!)
        let secondValue = Int(second.text!)

        
        
        if firstValue! == maxValue {
            
            if secondValue! == minvalue {
                
                submit.backgroundColor = UIColor.red
                
                submit.isEnabled = false
                
            }else {
                
                showNaNAlert()
                
            }
            
        }else {
            showNaNAlert()
            
        }
    }
    
    func showNaNAlert() {
        let alert = UIAlertController(title: "Not Matched",
                                      message: "Max value not Reached",
                                      preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
        
    }
    
//    func buttonEnable() {
//        if first.text == nil  {
//            submit.isEnabled = true
//        } else {
//            submit.isEnabled = false
//        }
//        
//    }
    
    
    @IBOutlet weak var userName: UITextField! {
        didSet {
            userName.delegate = self
            userName.addTarget(self, action:#selector(textDidChange(text:)) , for: .editingChanged)
        }
    }
    public func textDidChange(text:UITextField) {
        
        guard let name = userName.text,!name.isEmpty
             else {
                
                submit.isEnabled =  false
                submit.alpha = 0.5
                return
        }
        
        submit.isEnabled =  true
        submit.alpha = 1
    }


    @IBAction func resetBtn(_ sender: Any) {
        
        first.text = ""
        second.text = ""
        submit.backgroundColor = UIColor.white
        submit.isEnabled = true
        
    }
    
    
}

