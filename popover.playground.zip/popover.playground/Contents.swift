//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"




class JSHomeViewController: UIViewController ,UIPopoverControllerDelegate{
    
    var delegate: JSMenuTableViewControllerProtocol?
    var trainingId: Int?
    var enableDeclineButton: Bool = false
    var shouldShowSearchResults = false

func popOver () {
    
    let popupController = storyboard!.instantiateViewController(withIdentifier: "JSPopover") as! JSSuggestionDescriptionViewController
    popupController.modalPresentationStyle = .popover
    popupController.preferredContentSize = CGSize(width: CGFloat(360), height: CGFloat(80))
    if let popoverController = popupController.popoverPresentationController {
        popoverController.sourceView = self.view
        popoverController.sourceRect = CGRect( x: 210,y: 230, width: 0, height: 0)
        popoverController.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        popoverController.permittedArrowDirections = .any
        popoverController.delegate = self
        popupController.title = "Description"
    }
    present(popupController, animated: true, completion: nil)
}



//MARK:- UIPopOverPresentation Delegate
func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
    return UIModalPresentationStyle.none
}





// MARK: - TableView Delegates
extension JSHomeViewController: UITableViewDelegate,UITableViewDataSource,UIPopoverPresentationControllerDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if !shouldShowSearchResults {
            
            return headerModels.count
        }else {
            
            return 1
        }
        
}
//===========




    //
    //  JSHomeViewController.swift
    //  Jigyasa
    //
    //  Created by annapurna chandra on 13/12/16.
    //  Copyright © 2016-17 EXILANT Technologies Pvt. Ltd. All rights reserved.
    //
    
    import UIKit
    
    
    class JSHomeViewController: UIViewController,UIPopoverControllerDelegate {
        
        var delegate: JSMenuTableViewControllerProtocol?
        var trainingId: Int?
        var enableDeclineButton: Bool = false
        var shouldShowSearchResults = false
        let loggedInUserDefaults = JSUserDefaults()
        var isNominateAndRequestAvailable = false
        
        @IBOutlet var trainingTableView: UITableView!
        @IBOutlet var addTrainingButton: UIBarButtonItem!
        @IBOutlet weak var noSearchResults: UILabel!
        
        var trainingListDictionary: JSONDictionary = [:]
        let headerKeyArray = [JSTrainingListModelKey.myTrainings.rawValue,
                              JSTrainingListModelKey.todayTrainings.rawValue,
                              JSTrainingListModelKey.upComingTranings.rawValue,
                              JSTrainingListModelKey.trainingSuggestions.rawValue]
        var myTrainingsArray: [JSONDictionary]? = nil
        var todayTrainingsArray: [JSONDictionary]? = nil
        var upComingTraningsArray: [JSONDictionary]? = nil
        
        var headerModels: [JSHomeViewHeaderCellModel] = []
        
        @IBOutlet weak var searchBar: UISearchBar!
        
        private var isSearchBarEmpty: Bool {
            
            return searchBar.text?.isEmpty ??  false
        }
        var filteredTraining: [JSONDictionary] = []
        
        
        fileprivate let suggestTrainingIndex = 3
        
        fileprivate var previousSelectedHeaderIndex: Int? = 0
        
        //MARK: Default Method
        override func viewDidLoad() {
            
            super.viewDidLoad()
            searchBar.placeholder = "Search"
            searchBar.delegate = self
            //trainingTableView.setContentOffset(CGPoint(x: CGFloat(0), y: CGFloat(88)), animated: true)
            headerModels = getHeaderModels(forDictionary: nil)
            delegate?.addRightGestureToShowMenu(view: view)
            enableReturnKeyWithNoText()
            noSearchResults.isHidden = true
            //let userInfo = loggedInUserDefaults.getLoggedInUserInfo()
            //        if userInfo["employeeRoleId"] as! Int == 2 || userInfo["employeeRoleId"] as! Int == 3{
            //            navigationItem.rightBarButtonItem = nil
            //        }
            
        }
        
        override func viewWillAppear(_ animated: Bool) {
            super.viewWillAppear(animated)
            isNominateAndRequestAvailable = false
            getAllTrainings()
        }
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            
        }
        
        //MARK:- Buttom Actions
        
        @IBAction func MenuButtonAction(_ sender: UIBarButtonItem) {
            self.delegate?.showMenuViewController()
        }
        
        
        private func getAllTrainings() {
            
            let postbody = [
                "designation": "admin",
                JSEmployeeModelKey.employeeId.rawValue: 4308
                ] as [String : Any]
            
            let requestManager = JSServiceRequestManager.shared
            requestManager.dataTaskWithURL(postBody: postbody,
                                           urlEndString: JSServiceEndPoints.trainingList.rawValue)
            { (response) in
                
                guard let error = response[JSErrorMessage.errorMessage.rawValue]
                    else {
                        self.trainingListDictionary = response
                        self.trainingTableView.reloadData()
                        return
                }
                // show alert if error receiving data
                let alertController = UIAlertController(title: JSErrorMessage.errorMessage.rawValue, message: error as? String, preferredStyle: .alert)
                let OKAction = UIAlertAction(title: NSLocalizedString("OK_BUTTON", comment: "OK button title"), style: .default, handler: nil)
                alertController.addAction(OKAction)
                self.present(alertController, animated: true, completion: nil)
            }
        }
        
        // MARK: -  Navigation
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            
            if segue.identifier == "trainingDetails" {
                let trainingDetailsVC = segue.destination as! JSTrainingDetailsViewController
                trainingDetailsVC.trainingId = trainingId
                trainingDetailsVC.enableDeclineButton = enableDeclineButton
                trainingDetailsVC.isNominateAndRequestAvailable = isNominateAndRequestAvailable
            }
        }
        
        // MARK: - Filtering array
        func filterManagers(text:String) {
            
            let suggestionTrainingArray =   trainingListDictionary[JSTrainingListModelKey.trainingSuggestions.rawValue] as? [JSONDictionary]
            if !isSearchBarEmpty {
                var concatinatedDict = [JSONDictionary]()
                
                if let myTraining = myTrainingsArray {
                    concatinatedDict.append(contentsOf: myTraining)
                }
                if let todayTraining = todayTrainingsArray {
                    concatinatedDict.append(contentsOf: todayTraining)
                }
                if let upcomingTraining = upComingTraningsArray {
                    concatinatedDict.append(contentsOf: upcomingTraining)
                }
                
                if let suggesstionTraining = suggestionTrainingArray {
                    concatinatedDict.append(contentsOf: suggesstionTraining)
                }
                
                filteredTraining = concatinatedDict.filter{
                    if let titleName = $0["title"] as? String, let placeName = $0["location"] as? String {
                        if titleName.lowercased().hasPrefix(text) || placeName.lowercased().contains(text) {
                            
                            return true
                        }
                    }
                    else if let titleName = $0["title"] as? String, let suggestedBy = $0["suggestedBy"] as? String {
                        
                        if titleName.lowercased().hasPrefix(text) || suggestedBy.lowercased().contains(text) {
                            
                            return true
                        }
                    }
                    return false
                }
                noSearchResults.isHidden = filteredTraining.isEmpty ? false : true
            }else {
                noSearchResults.isHidden = true
                shouldShowSearchResults = false
            }
            
            trainingTableView.reloadData()
            
        }
        
    }
    
    extension JSHomeViewController: UISearchBarDelegate {
        
        
        func enableReturnKeyWithNoText() {
            // Find textfield in searchbar
            
            for subview in searchBar.subviews[0].subviews {
                
                if let subview = subview as? UITextField {
                    //makeing searchkey always enable
                    subview.enablesReturnKeyAutomatically = false
                    
                }
            }
        }
        
        // Return keyboard when user press search key
        func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
            
            searchBar.resignFirstResponder()
        }
        
        // MARK: - UISearchBarDelegate
        func searchBar(_ vasearchBar: UISearchBar, textDidChange searchText: String) {
            
            if let searchText = searchBar.text {
                shouldShowSearchResults = true
                filterManagers(text: searchText.lowercased())
            }
            
        }
        
        func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
            
            searchBar.resignFirstResponder()
        }
        
    }
    
    // MARK: - TableView Delegates
    extension JSHomeViewController: UITableViewDelegate,UITableViewDataSource,UIPopoverPresentationControllerDelegate {
        
        func numberOfSections(in tableView: UITableView) -> Int {
            if !shouldShowSearchResults {
                
                return headerModels.count
            }else {
                
                return 1
            }
            
        }
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            
            if shouldShowSearchResults {
                return filteredTraining.count
            }else{
                return headerModels[section].isExpanded == true ? (getRowsCount(forSection: section)) : 0
            }
        }
        
        func getRowsCount(forSection section:Int) -> Int {
            if trainingListDictionary.count == 0 {
                return 0
            }
            let headerKey = headerKeyArray[section]
            let headerArray = trainingListDictionary[headerKey] as? [JSONDictionary] ?? []
            return headerArray.count
            
        }
        
        func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
            
            if !shouldShowSearchResults {
                return CGFloat(30)
            }
            return CGFloat(0)
        }
        
        func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
            
            return createTrainingGroupHeaderCell(inTableView: tableView, withGroupTitle: "Swift and java", forSectionIndex: section)
        }
        
        
        // MARK: - TableView DataSourceDelegates
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            
            if shouldShowSearchResults {
                
                let temp = filteredTraining[indexPath.row]
                
                if  let title = temp["title"] as? String, let location = temp["location"] as? String {
                    
                    let trainingCell = tableView.dequeueReusableCell(withIdentifier: JSCellIdentifiers.trainingCellIdentifier.rawValue, for: indexPath) as? JSTrainingTableViewCell
                    trainingCell?.trainingTitle.text = title
                    trainingCell?.trainingLocation.text = location
                    trainingCell?.trainingDateAndTime.text = temp["startDateTime"] as? String ?? ""
                    return trainingCell!
                }else if let title = temp["title"] as? String, let suggestedBy = temp["suggestedBy"] as? String {
                    
                    let trainingSuggestionCell = tableView.dequeueReusableCell(withIdentifier: JSCellIdentifiers.suggestionTrainingCellIdentifier.rawValue, for: indexPath) as! JSTrainingSuggestionTableViewCell
                    trainingSuggestionCell.trainingSuggestionTitle.text = title
                    trainingSuggestionCell.employeeName.text = suggestedBy
                    trainingSuggestionCell.trainingSuggestionDescription.text = temp["description"] as? String ?? ""
                    return trainingSuggestionCell
                }
            }else
            {
                return createTrainingCell(inTableView: tableView, forIndexPath: indexPath)
                
            }
            return UITableViewCell()
        }
        
        //TODO: Need to handle delete functionality only for Admin role
        func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
            //to handle delete funtionality only for upcoming trainings and training suggestions.
            //check can be changed to indexpath.section if header section orders are fixed
            if (headerModels[indexPath.section].headerText == NSLocalizedString("UPCOMING_TRAININGS", comment: "")  || headerModels[indexPath.section].headerText == NSLocalizedString("SUGGEST_TRAININGS", comment: ""))
            {
                return true
            }
            return false
        }
        
        func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
            
            if (editingStyle == .delete){
                //TODO: Currently number of rows in a section is returning random count which is harcoded ,once that is fixed this can be uncommented
                //trainingTableView.beginUpdates()
                // trainingTableView.deleteRows(at: [indexPath], with: .fade)
                //trainingTableView.endUpdates()
            }
            
        }
        
        fileprivate func createTrainingCell(inTableView tableView:UITableView, forIndexPath indexPath:IndexPath) ->
            UITableViewCell {
                
                let trainingObj: JSONDictionary?
                myTrainingsArray = trainingListDictionary[JSTrainingListModelKey.myTrainings.rawValue] as? [JSONDictionary]
                todayTrainingsArray = trainingListDictionary[JSTrainingListModelKey.todayTrainings.rawValue] as? [JSONDictionary]
                upComingTraningsArray = trainingListDictionary[JSTrainingListModelKey.upComingTranings.rawValue] as? [JSONDictionary]
                checkTrainingType()
                if indexPath.section != suggestTrainingIndex {
                    let trainingCell = tableView.dequeueReusableCell(withIdentifier: JSCellIdentifiers.trainingCellIdentifier.rawValue, for: indexPath) as? JSTrainingTableViewCell
                    if indexPath.section == 0 {
                        trainingObj = myTrainingsArray?[indexPath.row]
                        trainingCell?.trainingTableViewCellData = JSTrainingModel(withData: trainingObj)
                        
                    }
                    else if indexPath.section == 1 {
                        trainingObj = todayTrainingsArray?[indexPath.row]
                        trainingCell?.trainingTableViewCellData = JSTrainingModel(withData: trainingObj)
                        
                    }
                    else {
                        trainingObj = upComingTraningsArray?[indexPath.row]
                        trainingCell?.trainingTableViewCellData = JSTrainingModel(withData: trainingObj)
                    }
                    
                    return trainingCell!
                    
                } else {
                    let trainingSuggestionCell = tableView.dequeueReusableCell(withIdentifier: JSCellIdentifiers.suggestionTrainingCellIdentifier.rawValue, for: indexPath) as! JSTrainingSuggestionTableViewCell
                    let trainingSuggestionsArray =
                        trainingListDictionary[JSTrainingListModelKey.trainingSuggestions.rawValue] as! [JSONDictionary]
                    let suggestionObj = trainingSuggestionsArray[indexPath.row]
                    trainingSuggestionCell.trainingSuggestionsCellData = JSTrainingSuggestionsModel(withData: suggestionObj)
                    
                    return trainingSuggestionCell
                }
        }
        
        func checkTrainingType() {
            
            if let myTraining = myTrainingsArray {
                for i in 0..<myTraining.count {
                    myTrainingsArray![i]["flag"] = 0
                }
            }
            if let todayTraining = todayTrainingsArray {
                for i in 0..<todayTraining.count {
                    todayTrainingsArray![i]["flag"] = 1
                }
            }
            if let upComingTraining = upComingTraningsArray {
                for i in 0..<upComingTraining.count {
                    upComingTraningsArray![i]["flag"] = 2
                }
            }
        }
        
        
        func popOver (y:CGFloat) {
            
            let popupController = storyboard!.instantiateViewController(withIdentifier: "JSPopover") as! JSDescriptionPopoverViewController
            popupController.modalPresentationStyle = .popover
            popupController.preferredContentSize = CGSize(width: CGFloat(360), height: CGFloat(80))
            if let popoverController = popupController.popoverPresentationController {
                popoverController.sourceView = self.view
                popoverController.sourceRect = CGRect( x: 0,y: y, width: 0, height: 0)
                popoverController.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
                popoverController.permittedArrowDirections = .down
                popoverController.delegate = self
                // popupController.descriptionView?.text = ""
            }
            present(popupController, animated: true, completion: nil)
        }
        
        
        
        //MARK:- UIPopOverPresentation Delegate
        func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
            return UIModalPresentationStyle.none
        }
        
        fileprivate func createTrainingGroupHeaderCell(inTableView tableView:UITableView, withGroupTitle title: String, forSectionIndex sectionIndex: Int) -> UIView {
            
            let trainingGroupHeaderCell = tableView.dequeueReusableCell(withIdentifier: JSCellIdentifiers.trainingGroupHeaderCellIdentifier.rawValue) as! JSTrainingGroupHeaderTableViewCell
            
            
            trainingGroupHeaderCell.groupTextLabel.text = headerModels[sectionIndex].headerText
            
            trainingGroupHeaderCell.groupCellButton.addTarget(self, action: #selector(JSHomeViewController.toggleHeaderSection(_:)), for: .touchUpInside)
            
            trainingGroupHeaderCell.groupCellButton.tag = sectionIndex
            
            if (headerModels[sectionIndex].isExpanded == true ) {
                
                updateGroupHeaderArrow(forImageView: trainingGroupHeaderCell.expandAndCollapseIcon, asIcon: JSHomeViewControllerConstants.kDownArrow.rawValue)
            } else {
                
                updateGroupHeaderArrow(forImageView: trainingGroupHeaderCell.expandAndCollapseIcon, asIcon: JSHomeViewControllerConstants.kRightArrow.rawValue)
            }
            
            return trainingGroupHeaderCell.contentView;
        }
        
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            let cell = tableView.cellForRow(at: indexPath)
            
            //cell?.contentView.frame.origin.x
            
            if indexPath.section == 1 || indexPath.section == 2
            {
                isNominateAndRequestAvailable = true
            }
            var trainingObject: JSONDictionary?
            if !shouldShowSearchResults{
                
                if indexPath.section == 0 {
                    trainingObject = (myTrainingsArray?[indexPath.row])!
                    trainingId = Int((trainingObject?[JSTrainingModelKey.trainingId.rawValue] as! String?)!)
                    enableDeclineButton = true
                }
                else if indexPath.section == 1 {
                    trainingObject = (todayTrainingsArray?[indexPath.row])!
                    trainingId = Int((trainingObject?[JSTrainingModelKey.trainingId.rawValue] as! String?)!)
                    enableDeclineButton = false
                }
                else {
                    //                    trainingObject = (upComingTraningsArray?[indexPath.row])!
                    //                    trainingId = Int((trainingObject?[JSTrainingModelKey.trainingId.rawValue] as! String?)!)
                    //                    enableDeclineButton = false
                    
                    popOver(y: (cell?.frame.origin.y)!)
                }
                if indexPath.section != 3 {
                    performSegue(withIdentifier: "trainingDetails", sender: self)
                }
                
            }
            else{
                let filterObject = filteredTraining[indexPath.row]
                if let suggestedBy = filterObject["suggestedBy"] as? String {
                    print(suggestedBy)
                }
                else {
                    if let flag = filterObject["flag"] as? Int {
                        if flag == 0 {
                            enableDeclineButton = true
                        }else if flag == 1 {
                            enableDeclineButton = false
                        }else{
                            enableDeclineButton = false
                        }
                    }
                    trainingObject = filteredTraining[indexPath.row]
                    trainingId = Int((trainingObject?[JSTrainingModelKey.trainingId.rawValue] as! String?)!)
                    performSegue(withIdentifier: "trainingDetails", sender: self)
                    
                }
            }
            
        }
    }
    
    
    
    
    //MARK: - Accordian action, pull to refresh and Add Training
    
    extension JSHomeViewController {
        
        func toggleHeaderSection(_ sender: UIButton){
            
            let sectionIndex = sender.tag
            
            if let haspreviousSelectedHeaderIndex = previousSelectedHeaderIndex {
                
                if haspreviousSelectedHeaderIndex != sectionIndex {
                    previousSelectedHeaderIndex = sectionIndex
                    headerModels[haspreviousSelectedHeaderIndex].isExpanded = !headerModels[haspreviousSelectedHeaderIndex].isExpanded
                    trainingTableView.reloadSections(IndexSet(integer:haspreviousSelectedHeaderIndex), with: .automatic)
                } else {
                    
                    return
                }
                
            } else {
                
                previousSelectedHeaderIndex = sectionIndex
            }
            
            headerModels[sectionIndex].isExpanded = !headerModels[sectionIndex].isExpanded
            trainingTableView.reloadSections(IndexSet(integer: sectionIndex), with: .fade)
            
        }
        
        func updateGroupHeaderArrow(forImageView imageView: UIImageView, asIcon icon: String) {
            
            UIView.animate(withDuration: 0.5, animations: {
                imageView.image = UIImage(named: icon)
            })
        }
    }
    
    extension UITableView {
        
        var isTableHeaderViewVisible: Bool {
            
            guard let tableHeaderView = tableHeaderView else {
                return false
            }
            
            let currentYOffset = self.contentOffset.y;
            let headerHeight = tableHeaderView.frame.size.height;
            
            return currentYOffset < headerHeight
        }
    }
    
    //MARK: - Custom Function
    extension JSHomeViewController {
        
        func getHeaderModels(forDictionary dictionary: [String:Any]?) -> [JSHomeViewHeaderCellModel] {
            
            let headerModels = [JSHomeViewHeaderCellModel(forSectionIndex: 0, withHeaderText: NSLocalizedString("MY_TRAININGS", comment: ""), andIsExpanded: true),
                                JSHomeViewHeaderCellModel(forSectionIndex: 1, withHeaderText: NSLocalizedString("TODAY'S_TRAININGS", comment: ""), andIsExpanded: false),
                                JSHomeViewHeaderCellModel(forSectionIndex: 2, withHeaderText: NSLocalizedString("UPCOMING_TRAININGS", comment: ""), andIsExpanded: false),
                                JSHomeViewHeaderCellModel(forSectionIndex: 3, withHeaderText: NSLocalizedString("SUGGEST_TRAININGS", comment: ""), andIsExpanded: false) ]
            
            return headerModels
        }
}








