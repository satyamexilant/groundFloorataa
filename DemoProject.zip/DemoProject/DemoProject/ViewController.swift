//
//  ViewController.swift
//  DemoProject
//
//  Created by medidi vv satyanarayana murty on 14/09/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var number: UITextField!
    @IBOutlet weak var display: UILabel!
    @IBOutlet weak var displayNumber: UILabel!
    @IBOutlet weak var send: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
       hidden()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }

    @IBAction func add(_ sender: Any) {
        
        enable()
        display.text = name.text
        displayNumber.text = number.text
        name.text = ""
        number.text = ""
    }
    
    @IBAction func send(_ sender: Any) {
        
        
    }
    
    func hidden() {
        self.display.isHidden = true
        self.displayNumber.isHidden = true
        self.send.isHidden = true
    }
    
    func enable () {
        
        self.display.isHidden = false
        self.displayNumber.isHidden = false
        self.send.isHidden = false
        
    }
    
    
   
}

