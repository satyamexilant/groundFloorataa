//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .white

        let label = UILabel()
        label.frame = CGRect(x: 150, y: 200, width: 200, height: 20)
        label.text = "Hello World!"
        label.textColor = .black
        
        view.addSubview(label)
        self.view = view
    }
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()



//func reverseWords(s: String) -> String {
//    var tmp = s.componentsSeparatedByCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
//    tmp = tmp.filter{ $0 != "" }.reverse()
//    return " ".join(tmp)
//}





//
//func reverseWords(s: String) -> String {
//    var newS: String = ""
//    var bufferS: String = ""
//    func joinBufferS() {
//        if !bufferS.isEmpty {
//            let midS = newS.isEmpty ? "" : " "
//            newS = bufferS + midS + newS
//            bufferS = ""
//        }
//    }
//    for c in s {
//        if String(c) == " " {
//            joinBufferS()
//        } else {
//            bufferS += String(c)
//        }
//    }
//    joinBufferS()
//    return newS
//}




//let word = "Backwards"
//for char in word.reversed() {
//    print(char, terminator: "")
//}
//
////func reverseSentence(input:String) -> String) {
//let sentence1 = "Welcome to Exilant"
//
//   // for i in 0...(sentence1.count) {
//        
//        let reversed = String(sentence1.characters.reversed())
//if reversed != "" {
//    
//}
//    //}
//
//print(reversed)
////}





var sentence2 = "Hello world"
func reverseWordInSentence(sentence:String) -> String {
    
   var out = sentence2.components(separatedBy: " ")
    var newsenc = ""
//    for word in out  {
//        if newsenc != ""{
//            newsenc  += " "
//        }
//        let reverseSentence = String(word.characters.reversed())
//        newsenc += word
//    }
    
    
    
    for index in 0...(out.count)-1 {
        
        let word = out[index]
        if newsenc != ""{
            newsenc  += " "
        }
        let reverseSentence = String(word.characters.reversed())
      
        newsenc += word
        print(reverseSentence)
    }
return newsenc
}

print(reverseWordInSentence(sentence: sentence2))


for  i in 0 ... 4 {
    print("+++")
}

enum Sample:String {
    case East = "News"
}
Sample.East.rawValue


class Sample8 {
    var name : String
    init(name:String) {
        self.name = name
    }
}

var a = Sample8(name:"Exilant")
var b = a
b.name = "Fusion"
print(a.name)
print(b.name)

struct Sample9 {
    var name:String
    init(name:String) {
        self.name = name
    }
}
var sa = Sample9(name:"Hai")
var sb = sa
sb.name =  "Bye"
print(sa.name)
print(sb.name)




